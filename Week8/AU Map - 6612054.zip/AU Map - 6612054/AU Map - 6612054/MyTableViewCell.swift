//
//  MyTableViewCell.swift
//  AU Map - 6612054
//
//  Created by Win Yu Maung on 17/08/2024.
//

import UIKit

class MyTableViewCell: UITableViewCell {
    
    @IBOutlet weak var Logo: UIImageView!
    @IBOutlet weak var faculty: UILabel!
    @IBOutlet weak var brief: UILabel!
    @IBOutlet weak var distance: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
