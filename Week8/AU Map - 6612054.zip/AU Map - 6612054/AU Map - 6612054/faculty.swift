//
//  faculty.swift
//  AU Map - 6612054
//
//  Created by Win Yu Maung on 17/08/2024.
//

import Foundation

struct Place : Codable {
    let FacultyName : String
    let Abbreviation : String
    let ImageLogoName : String
    let LocationLat : Double
    let LocationLong : Double
}
