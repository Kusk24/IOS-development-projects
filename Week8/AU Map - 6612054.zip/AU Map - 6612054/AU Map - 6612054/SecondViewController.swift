//
//  SecondViewController.swift
//  AU Map - 6612054
//
//  Created by Win Yu Maung on 17/08/2024.
//

import UIKit
import CoreLocation


class SecondViewController: UIViewController,UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return places.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Mycell") as! MyTableViewCell
        let i = indexPath.row
        
        let location = CLLocation(latitude: places[i].LocationLat, longitude: places[i].LocationLong)
        let distance = userLocation?.distance(from: location) ?? 0
        let distanceString = String(format: "%.2f meters", distance)
        
       
        cell.faculty.text = places[i].FacultyName
        cell.brief.text = places[i].Abbreviation
        cell.Logo.image = UIImage(named: places[i].ImageLogoName)
        cell.distance.text = distanceString
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 140
    }
    

    @IBOutlet weak var tableview: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        tableview.dataSource = self
        tableview.delegate = self
        // Do any additional setup after loading the view.

    }

}
