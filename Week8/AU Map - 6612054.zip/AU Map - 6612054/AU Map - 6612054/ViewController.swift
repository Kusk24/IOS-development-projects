//
//  ViewController.swift
//  AU Map - 6612054
//
//  Created by Win Yu Maung on 17/08/2024.
//

import UIKit
import MapKit

var places: [Place] = []
var userLocation: CLLocation? = CLLocation(latitude: 13.612320, longitude: 100.836808)


class ViewController: UIViewController,MKMapViewDelegate, CLLocationManagerDelegate {

    @IBOutlet weak var mapView: MKMapView!
    
    let locationManager = CLLocationManager()

    override func viewDidLoad() {
        super.viewDidLoad()
        loadJSON()
        
        mapView.delegate = self
        locationManager.delegate = self
        
        locationManager.requestWhenInUseAuthorization()
        locationManager.startUpdatingLocation()

        let initialLocation = CLLocation(latitude: 13.612320, longitude: 100.836808)
        centerMapOnLocation(location: initialLocation)

        addFacultyAnnotations()
    }

    func centerMapOnLocation(location: CLLocation) {
        let regionRadius: CLLocationDistance = 1000
        let coordinateRegion = MKCoordinateRegion(center: location.coordinate,
                                                  latitudinalMeters: regionRadius, longitudinalMeters: regionRadius)
        mapView.setRegion(coordinateRegion, animated: true)
    }

    func addFacultyAnnotations() {
        for faculty in places {
            let annotation = MKPointAnnotation()
            annotation.title = faculty.FacultyName
            annotation.subtitle = faculty.Abbreviation
            annotation.coordinate = CLLocationCoordinate2D(latitude: faculty.LocationLat, longitude: faculty.LocationLong)
            mapView.addAnnotation(annotation)
        }
        let annotation = MKPointAnnotation()
        annotation.title = "MyPlace"
        annotation.coordinate = CLLocationCoordinate2D(latitude: 13.612320, longitude: 100.836808)
        mapView.addAnnotation(annotation)
    }

    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        let identifier = "FacultyPin"
        var annotationView = mapView.dequeueReusableAnnotationView(withIdentifier: identifier) as? MKMarkerAnnotationView

        if annotationView == nil {
            annotationView = MKMarkerAnnotationView(annotation: annotation, reuseIdentifier: identifier)
            annotationView?.canShowCallout = true
            
            let btn = UIButton(type: .detailDisclosure)
            annotationView?.rightCalloutAccessoryView = btn
        } else {
            annotationView?.annotation = annotation
        }

        return annotationView
    }

    // Handle the detail button tap event to show an AlertView with the faculty's info
    func mapView(_ mapView: MKMapView, annotationView view: MKAnnotationView, calloutAccessoryControlTapped control: UIControl) {
        if let annotation = view.annotation {
            let title = annotation.title ?? ""
            let annotationLocation = CLLocation(latitude: annotation.coordinate.latitude, longitude: annotation.coordinate.longitude)
            
            // Calculate the distance from user's location to the annotation
            let distance = userLocation?.distance(from: annotationLocation) ?? 0
            let distanceString = String(format: "%.2f meters", distance)
            
            let message = """
            Coordinates: \(annotation.coordinate.latitude), \(annotation.coordinate.longitude)
            Distance from you: \(distanceString)
            """
            
            let ac = UIAlertController(title: title, message: message, preferredStyle: .alert)
            ac.addAction(UIAlertAction(title: "OK", style: .default))
            present(ac, animated: true)
        }
    }

    // Handle location updates
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        userLocation = locations.last
    }

    // Handle location permission changes
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        if status == .authorizedWhenInUse {
            mapView.showsUserLocation = true
        }
    }

    func loadJSON() {
        if let path = Bundle.main.path(forResource: "abac_location", ofType: "json") {
            do {
                let data = try Data(contentsOf: URL(fileURLWithPath: path))
                let decoder = JSONDecoder()
                let jsonResponse = try decoder.decode([String: [Place]].self, from: data)
                
                if let loadedPlaces = jsonResponse["Places"] {
                    places = loadedPlaces
                }
                
            } catch {
                print("Error parsing JSON: \(error)")
            }
        }
    }
}
