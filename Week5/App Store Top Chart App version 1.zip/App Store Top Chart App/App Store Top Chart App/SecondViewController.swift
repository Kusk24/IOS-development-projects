//
//  SecondViewController.swift
//  App Store Top Chart App
//
//  Created by Win Yu Maung on 19/07/2024.
//

import UIKit

class SecondViewController: UIViewController {

    @IBOutlet weak var image1: UIImageView!
    @IBOutlet weak var image2: UIImageView!
    @IBOutlet weak var image3: UIImageView!
    @IBOutlet weak var image4: UIImageView!
    @IBOutlet weak var image5: UIImageView!
    @IBOutlet weak var image6: UIImageView!
    @IBOutlet weak var MyView: UIView!
    @IBOutlet weak var image7: UIImageView!
    @IBOutlet weak var image8: UIImageView!
    
    @IBOutlet weak var Label1: UILabel!
    @IBOutlet weak var Label2: UILabel!
    @IBOutlet weak var Label3: UILabel!
    @IBOutlet weak var Label4: UILabel!
    @IBOutlet weak var Label5: UILabel!
    @IBOutlet weak var Label6: UILabel!
    @IBOutlet weak var Label7: UILabel!
    @IBOutlet weak var MyScroll: UIScrollView!
    
    var App : AppInfo?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        Label1.text = App?.appName
        Label2.text = App?.appName
        Label3.text = App?.shortDescription
        Label4.text = String(App?.rating ?? 0.0)
        Label5.text = (App?.age ?? "0")
        Label6.text = "#" +  String(App?.topChartPosition ?? 0)
        Label7.text = App?.detailedDescription
        
        image5.image = UIImage(named: App?.appIcon ?? "")
        image5.layer.cornerRadius = 15
        image5.layer.masksToBounds = true
        // Do any additional setup after loading the view.


        func Looping(A: [UIImageView], B: [String]) {
            var e = 0
            for i in B {
                A[e].image = UIImage(named: i)
                e += 1
            }
        
        }
        if let screenshot = App?.screenshotGallery {
            let myImages: [UIImageView]
            switch screenshot.count {
                case 1:
                    myImages = [image1]
                    MyView.trailingAnchor.constraint(equalTo: image1.trailingAnchor, constant: 20).isActive = true
                case 2:
                    myImages = [image1,image2]
                    MyView.trailingAnchor.constraint(equalTo: image2.trailingAnchor, constant: 20).isActive = true
                case 3:
                    myImages = [image1,image2,image3]
                    MyView.trailingAnchor.constraint(equalTo: image3.trailingAnchor, constant: 20).isActive = true
                case 4:
                    myImages = [image1,image2,image3,image4]
                    MyView.trailingAnchor.constraint(equalTo: image4.trailingAnchor, constant: 20).isActive = true
                case 5:
                    myImages = [image1,image2,image3,image4,image6]
                    MyView.trailingAnchor.constraint(equalTo: image6.trailingAnchor, constant: 20).isActive = true
                case 6:
                    myImages = [image1,image2,image3,image4,image6,image7]
                    MyView.trailingAnchor.constraint(equalTo: image7.trailingAnchor, constant: 20).isActive = true
                case 7:
                    myImages = [image1,image2,image3,image4,image6,image7,image8]
                    MyView.trailingAnchor.constraint(equalTo: image8.trailingAnchor, constant: 20).isActive = true
                default:
                    myImages = []
                }
                
            
                Looping(A: myImages, B: screenshot)
                
            }

    }
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
