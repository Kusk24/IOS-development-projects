//
//  ViewController.swift
//  App Store Top Chart App
//
//  Created by Win Yu Maung on 16/07/2024.
//  Name - Win Yu Maung
//  ID - 6612054
//  Sec - 542
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return topTenApps.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableview.dequeueReusableCell(withIdentifier: "cell") as! TableViewCell
        cell.appIcon.image = UIImage(named: topTenApps[indexPath.row].appIcon)
        cell.appIcon.layer.cornerRadius = 15
        cell.appIcon.layer.masksToBounds = true
        cell.appName.text = topTenApps[indexPath.row].appName
        cell.shortDescription.text = topTenApps[indexPath.row].shortDescription
                        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 110
    }
    

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let second = storyboard?.instantiateViewController(withIdentifier: "secondPage") as! SecondViewController
        
        second.App = topTenApps[indexPath.row]
        
        second.navigationItem.largeTitleDisplayMode = .never
        navigationController?.pushViewController(second, animated: true)
    }

    
    
    @IBOutlet weak var tableview: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        navigationController?.navigationBar.prefersLargeTitles = true
        
        tableview.delegate = self
        tableview.dataSource = self
    }


}

