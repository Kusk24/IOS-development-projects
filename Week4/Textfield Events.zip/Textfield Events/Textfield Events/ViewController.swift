//
//  ViewController.swift
//  Textfield Events
//
//  Created by Win Yu Maung on 29/06/2024.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var phoneNumberTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func TextFieldOnEditingDidBegin(_ sender: Any) {
    }
    
    @IBAction func textFieldOnEditingChanged(_ sender: Any) {
      
    }
    
    @IBAction func TextFieldOnEditingChanged(_ sender: Any) {
        if let currentInput = phoneNumberTextField.text {
            print(currentInput)
            if currentInput.count == 4 {
                let firstPart = currentInput.substring(to: currentInput.count - 1)
                let hyphen = "-"
                let lastPart = currentInput.substring(from: currentInput.count)
                phoneNumberTextField.text = "\(firstPart)\(hyphen)\(lastPart)"
            }
            if  currentInput.count == 8 {
                let firstPart = currentInput.substring(to: currentInput.count - 1)
                let hyphen = "-"
                let lastPart = currentInput.substring(from: currentInput.count)
                
                phoneNumberTextField.text = "\(firstPart)\(hyphen)\(lastPart)"
                }
        }
    }
    
    
}

