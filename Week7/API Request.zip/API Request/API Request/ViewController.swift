//
//  ViewController.swift
//  API Request
//
//  Created by Win Yu Maung on 10/08/2024.
//

import UIKit
import Alamofire

struct Person: Codable {
    var firstname: String
    var lastname: String
    var age: Int
    var gender: String
    var devices: [Device]
}

struct Device: Codable{
    var type: String
    var model: String
}
class ViewController: UIViewController {

    @IBOutlet var firstnameLabel: UILabel!
    @IBOutlet var lastnameLabel: UILabel!
    @IBOutlet var ageLabel: UILabel!
    @IBOutlet var genderLabel: UILabel!
    
    var person: Person? = nil

    override func viewDidLoad() {
        super.viewDidLoad()
        
        //        AF.request("https://www.google.com").responseString { Result in
        //            print(Result)
        //        }
 
    }
    
    func updateUI() {
        if let person = person {
            firstnameLabel.text = person.firstname
            lastnameLabel.text = person.lastname
            ageLabel.text = "\(person.age)"
            genderLabel.text = person.gender
            
            person.devices.forEach {device in
                print(device.type)
                print(device.model)
            }
        }
    }


}

