//
//  ViewController.swift
//  Constraint Demo
//
//  Created by Win Yu Maung on 23/06/2024.
// ID - 6612054
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

