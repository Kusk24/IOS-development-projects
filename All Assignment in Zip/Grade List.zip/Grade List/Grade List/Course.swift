//
//  Course.swift
//  Grade List
//
//  Created by Win Yu Maung on 17/08/2024.
//

struct Course: Codable {
    var code: String
    var credit: Double
    var name: String
    var grade: String
}

struct CoursesResponse: Codable {
    var name: String
    var grades: [Course]
}
