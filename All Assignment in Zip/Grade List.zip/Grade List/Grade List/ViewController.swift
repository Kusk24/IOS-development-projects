//
//  ViewController.swift
//  Grade List
//
//  Created by Win Yu Maung on 17/08/2024.
//

import UIKit
import Alamofire

class ViewController: UIViewController, UITableViewDelegate,UITableViewDataSource {
    
    var info: CoursesResponse!
    var mycount: Int = 0
    
    @IBOutlet weak var tableview: UITableView!
    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        tableview.delegate = self
        tableview.dataSource = self
        
        AF.request("https://dl.dropboxusercontent.com/s/nsicnigp0xc8dxz/grades.json").responseDecodable(of: CoursesResponse.self) { data in
            switch data.result {
            case .success(let courseResponse):
                self.info = courseResponse
                self.mycount = courseResponse.grades.count
                self.tableView.reloadData()
            case .failure(let error):
                print(error)
            }
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return mycount
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell") as! MyTableViewCell
        let i = indexPath.row

        cell.Code.text = info.grades[i].code
        cell.Name.text = info.grades[i].name
        cell.Credit.text = String(info.grades[i].credit) + " CR."
        cell.Grade.text = info.grades[i].grade
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 80
    }
}
