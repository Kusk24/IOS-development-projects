//
//  MyTableViewCell.swift
//  Grade List
//
//  Created by Win Yu Maung on 17/08/2024.
//

import UIKit

class MyTableViewCell: UITableViewCell {
    @IBOutlet weak var Code: UILabel!
    @IBOutlet weak var Credit: UILabel!
    @IBOutlet weak var Name: UILabel!
    @IBOutlet weak var Grade: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
