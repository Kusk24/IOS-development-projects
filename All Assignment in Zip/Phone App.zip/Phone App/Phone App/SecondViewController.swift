//
//  SecondViewController.swift
//  Phone App
//
//  Created by Win Yu Maung on 12/07/2024.
//

import UIKit

class SecondViewController: UIViewController {

    @IBOutlet weak var PhoneNumber: UILabel!
    @IBOutlet weak var End: UIButton!
    
    public var text : String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        End.layer.cornerRadius = End.frame.height / 2
        End.layer.masksToBounds = true
        
        if text != nil {
            PhoneNumber.text = text
        }
    }
    
    @IBAction func EndCall(_ sender: Any) {
        self.dismiss(animated: true)
    }
    

}
