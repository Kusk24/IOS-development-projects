//
//  ViewController.swift
//  Phone App
//
//  Created by Win Yu Maung on 11/07/2024.
//  Name - Win Yu Maung
//  ID - 6612054
//  Sec - 542
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var One: UIButton!
    @IBOutlet weak var Two: UIButton!
    @IBOutlet weak var Three: UIButton!
    @IBOutlet weak var Four: UIButton!
    @IBOutlet weak var Five: UIButton!
    @IBOutlet weak var Six: UIButton!
    @IBOutlet weak var Seven: UIButton!
    @IBOutlet weak var Eight: UIButton!
    @IBOutlet weak var Nine: UIButton!
    @IBOutlet weak var Star: UIButton!
    @IBOutlet weak var Zero: UIButton!
    @IBOutlet weak var Hash: UIButton!
    @IBOutlet weak var Call: UIButton!
    @IBOutlet weak var Delete: UIButton!
    @IBOutlet weak var Number: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        func cir (a: UIButton) {
            a.layer.cornerRadius = a.frame.height / 2
            a.layer.masksToBounds = true
        }
        
        cir(a: One)
        cir(a: Two)
        cir(a: Three)
        cir(a: Four)
        cir(a: Five)
        cir(a: Six)
        cir(a: Seven)
        cir(a: Eight)
        cir(a: Nine)
        cir(a: Zero)
        cir(a: Star)
        cir(a: Hash)
        cir(a: Call)
    }
    
    
    @IBAction func ShowNumber(B : UIButton) {
        
        if let currentText = Number.text {
            switch B.tag {
            case 1:
                Number.text = currentText + "1"
            case 2:
                Number.text = currentText + "2"
            case 3:
                Number.text = currentText + "3"
            case 4:
                Number.text = currentText + "4"
            case 5:
                Number.text = currentText + "5"
            case 6:
                Number.text = currentText + "6"
            case 7:
                Number.text = currentText + "7"
            case 8:
                Number.text = currentText + "8"
            case 9:
                Number.text = currentText + "9"
            case 0:
                Number.text = currentText + "0"
            case 10:
                Number.text = currentText + "*"
            case 11:
                Number.text = currentText + "#"
            case 12:
                Number.text = String(currentText.dropLast())
            default:
                break
            }
            
        }
    }
    
    
    @IBAction func CallforPhone(_ sender: Any) {
        let secondscreen = storyboard?.instantiateViewController(withIdentifier: "Second") as! SecondViewController
        secondscreen.text = Number.text
        secondscreen.modalPresentationStyle = .fullScreen
        present(secondscreen, animated: true)
}
    
    
}

