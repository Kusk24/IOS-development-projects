//
//  ViewController.swift
//  Assignment 2
//
//  Created by Win Yu Maung on 11/06/2024.
//
// Name - Win Yu Maung
// ID - 6612054
// Section - 542

import UIKit

class ViewController: UIViewController {

    @IBOutlet var Name: UILabel!
    @IBOutlet var Your_Age: UILabel!
    
    @IBOutlet var FirstName: UITextField!
    @IBOutlet var LastName: UITextField!
    @IBOutlet var year: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func ClickMeButtonClicked() {
        let Fname = FirstName.text
        let Lname = LastName.text
        let age = year.text
        
        Name.text = "Your name is \(Fname!) \(Lname!)."
        Your_Age.text = "You are \(age!) years old."
    }
}

