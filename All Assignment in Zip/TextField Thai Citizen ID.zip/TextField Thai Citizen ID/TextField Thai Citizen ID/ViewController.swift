//
//  ViewController.swift
//  TextField Thai Citizen ID
//
//  Created by Win Yu Maung on 29/06/2024.
// Name - Win Yu Maung
// ID - 6612054
// Section - 542
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var idNumberTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func textFieldOnEditingChanged(_ sender: Any) {
    
        if let currentInput = idNumberTextField.text {
            print(currentInput)
            
            switch currentInput.count {
            case 2:
                idNumberTextField.text = currentInput.substring(to: 1) + "-" + currentInput.substring(from: currentInput.count-1)
            case 6:
                idNumberTextField.text = currentInput + "-"
            case 13:
                idNumberTextField.text = currentInput + "-"
            case 16:
                idNumberTextField.text = currentInput + "-"
            case 17:
                idNumberTextField.text = currentInput + "-"
            case 19:
                let limit = currentInput.substring(to: 18)
                idNumberTextField.text = limit
                idNumberTextField.resignFirstResponder()
            default:
                break
            }
            
        }
    }

    @IBAction func ImdonebuttonClicked(_ sender: Any) {
        idNumberTextField.resignFirstResponder()
    }
    
}

