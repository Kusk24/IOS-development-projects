//
//  ViewController.swift
//  First App
//
//  Created by Win Yu Maung on 09/06/2024.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet var animal: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func clickMeButtonClicked1() {
        animal.text = "Shark"
    }
    
    @IBAction func clickMeButtonClicked2() {
        animal.text = "Clownfish"
    }
    
    @IBAction func clickMeButtonClicked3() {
        animal.text = "Octopus"
    }
    
    @IBAction func clickMeButtonClicked4() {
        animal.text = "Leafy Seadragon"
    }
    
    @IBAction func clickMeButtonClicked5() {
        animal.text = "Otter"
    }
    
    @IBAction func clickMeButtonClicked6() {
        animal.text = "Turtle"
    }
    
    @IBAction func resetClicked() {
        animal.text = ""
    }
    
}

