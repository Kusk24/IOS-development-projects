//
//  PlanetCell.swift
//  Planets
//
//  Created by Win Yu Maung on 24/08/2024.
//

import UIKit

class PlanetCell: UICollectionViewCell {
    @IBOutlet weak var planetimage: UIImageView!
    @IBOutlet weak var planetname: UILabel!
    
}
