//
//  ViewController.swift
//  Vowels_Counter
//
//  Created by Win Yu Maung on 05/07/2024.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var InputText: UITextField!
    
    @IBOutlet weak var ForA: UIView!
    @IBOutlet weak var ForO: UIView!
    @IBOutlet weak var ForE: UIView!
    @IBOutlet weak var ForU: UIView!
    @IBOutlet weak var ForI: UIView!
    
    @IBOutlet weak var ForAcount: UILabel!
    @IBOutlet weak var ForOcount: UILabel!
    @IBOutlet weak var ForEcount: UILabel!
    @IBOutlet weak var ForUcount: UILabel!
    @IBOutlet weak var ForIcount: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func EditingChanged(_ sender: Any) {
        if let word = InputText.text {
            
            var countA: Int = 0
            var countE: Int = 0
            var countI: Int = 0
            var countO: Int = 0
            var countU: Int = 0
            
            for letter in word {
                switch letter {
                case "A","a":
                    countA += 1
                case "E","e":
                    countE += 1
                case "I","i":
                    countI += 1
                case "O","o":
                    countO += 1
                case "U","u":
                    countU += 1
                default:
                    break
                }
            }

           
            func Color(a: inout Int, b: UILabel, c: UIView) {
                switch a{
                case 1...Int.max:
                    c.backgroundColor = .green
                    b.text = "x" + String(a)
                case 0:
                    c.backgroundColor = .systemGray4
                    b.text = "x" + String(a)
                default:
                    break
                }
            }
            
            Color(a: &countA, b: ForAcount, c:ForA)
            Color(a: &countE, b: ForEcount, c:ForE)
            Color(a: &countI, b: ForIcount, c:ForI)
            Color(a: &countO, b: ForOcount, c:ForO)
            Color(a: &countU, b: ForUcount, c:ForU)
            
            /*
            for letter in word {
                switch letter {
                case letter where ["A","a"].contains(letter):
                    countA += 1
                case letter where ["E","e"].contains(letter):
                    countE += 1
                case letter where ["I","i"].contains(letter):
                    countI += 1
                case letter where ["O","o"].contains(letter):
                    countO += 1
                case letter where ["U","u"].contains(letter):
                    countU += 1
                default:
                    break
                }
            }
            switch countA {
            case 1...Int.max:
                ForA.backgroundColor = .green
                ForAcount.text = "x" + String(countA)
            case 0:
                ForA.backgroundColor = .systemGray4
                ForAcount.text = "x" + String(countA)
            default:
                break
            }
            
            switch countE {
            case 1...Int.max:
                ForE.backgroundColor = .green
                ForEcount.text = "x" + String(countE)
            case 0:
                ForE.backgroundColor = .systemGray4
                ForEcount.text = "x" + String(countE)
            default:
                break
            }
            
            switch countI {
            case 1...Int.max:
                ForI.backgroundColor = .green
                ForIcount.text = "x" + String(countI)
            case 0:
                ForI.backgroundColor = .systemGray4
                ForIcount.text = "x" + String(countI)
            default:
                break
            }
            
            switch countO {
            case 1...Int.max:
                ForO.backgroundColor = .green
                ForOcount.text = "x" + String(countO)
            case 0:
                ForO.backgroundColor = .systemGray4
                ForOcount.text = "x" + String(countO)
            default:
                break
            }

            switch countU {
            case 1...Int.max:
                ForU.backgroundColor = .green
                ForUcount.text = "x" + String(countU)
            case 0:
                ForU.backgroundColor = .systemGray4
                ForUcount.text = "x" + String(countU)
            default:
                break
            }
*/
        }
    }
    
}

