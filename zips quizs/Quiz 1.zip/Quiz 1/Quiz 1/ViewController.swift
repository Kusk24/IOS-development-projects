//
//  ViewController.swift
//  Quiz 1
//
//  Created by Win Yu Maung on 15/06/2024.
//
// Name - Win Yu Maung
// ID - 6612054
// Sec - 542

import UIKit

class ViewController: UIViewController {

    @IBOutlet var Label: UILabel!
    @IBOutlet var Image: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func randomclicked(button: UIButton) {
        let i = [1,2,3,4,5,6].randomElement()
        
        button.tag = i!
        
        switch button.tag {
        case 1:
            Image.image = #imageLiteral(resourceName: "Shark.jpeg")
            Label.text = "Shark"
        case 2:
            Image.image = #imageLiteral(resourceName: "Clown Fish.jpeg")
            Label.text = "Clownfish"
        case 3:
            Image.image = #imageLiteral(resourceName: "Octopus.jpeg")
            Label.text = "Octopus"
        case 4:
            Image.image = #imageLiteral(resourceName: "Leafy seadragon.jpg")
            Label.text = "Leafy Seadragon"
        case 5:
            Image.image = #imageLiteral(resourceName: "Otter.jpeg")
            Label.text = "Otter"
        case 6:
            Image.image = #imageLiteral(resourceName: "Turtle.jpeg")
            Label.text = "Turtle"
        default:
            break
        }
    }
}

