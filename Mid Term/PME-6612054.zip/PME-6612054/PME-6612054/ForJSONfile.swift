//
//  File.swift
//  PME-6612054
//
//  Created by Win Yu Maung on 27/07/2024.
//

import Foundation

// Define the structure of an Item
struct Item: Codable {
    let name: String
    let location: String
    let description: String
    let rating: Double
    let openingTime: String
    let price: String
    let images: [String]
}

// Define the structure of the root JSON object
struct RestaurantData: Codable {
    let items: [Item]
}
