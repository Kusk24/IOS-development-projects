//
//  ReadingJSONFile.swift
//  PME-6612054
//
//  Created by Win Yu Maung on 27/07/2024.
//

import Foundation

// Function to load JSON data from a file
class JSONParser {
    
    static func loadJSON(filename fileName: String) -> RestaurantData? {
        if let url = Bundle.main.url(forResource: fileName, withExtension: "json") {
            do {
                let data = try Data(contentsOf: url)
                let decoder = JSONDecoder()
                let jsonData = try decoder.decode(RestaurantData.self, from: data)
                return jsonData
            } catch {
                print("Error: \(error)")
            }
        }
        return nil
    }
}

var itemList : [Item] = []


