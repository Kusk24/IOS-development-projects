//
//  SecondTableViewCell.swift
//  PME-6612054
//
//  Created by Win Yu Maung on 27/07/2024.
//

import UIKit

class SecondTableViewCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
