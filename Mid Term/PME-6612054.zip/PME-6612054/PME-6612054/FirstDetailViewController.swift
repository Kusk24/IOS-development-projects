//
//  FirstDetailViewController.swift
//  PME-6612054
//
//  Created by Win Yu Maung on 27/07/2024.
//

import UIKit

class FirstDetailViewController: UIViewController {

    var mine : Item!
    @IBOutlet weak var Image: UIImageView!
    @IBOutlet weak var Name: UILabel!
    @IBOutlet weak var Location: UILabel!
    @IBOutlet weak var image1: UIImageView!
    @IBOutlet weak var image2: UIImageView!
    @IBOutlet weak var image3: UIImageView!
    @IBOutlet weak var image4: UIImageView!
    @IBOutlet weak var image5: UIImageView!
    @IBOutlet weak var rating: UILabel!
    @IBOutlet weak var time: UILabel!
    @IBOutlet weak var price: UILabel!
    @IBOutlet weak var detail: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
            
        Image.image = UIImage(named: mine.images[1])
        Name.text = mine.name
        Location.text = mine.location
        rating.text = String(mine.rating)
        detail.text = mine.description
        time.text = mine.openingTime
        price.text = mine.price
        
        let myimages: [UIImageView]

        switch mine.rating {
        case ..<2:
            myimages = [image1]
        case 2..<3:
            myimages = [image1, image2]
        case 3..<4:
            myimages = [image1, image2, image3]
        case 4..<5:
            myimages = [image1, image2, image3, image4]
        case 5...6:
            myimages = [image1, image2, image3, image4, image5]
        default:
            myimages = []
        }

        // Set star images
        let allImages = [image1, image2, image3, image4, image5]
        for (index, imageView) in allImages.enumerated() {
            if index < myimages.count {
                imageView?.image = UIImage(systemName: "star.fill")
            } else {
                imageView?.image = UIImage(systemName: "star") // Assuming you want to clear or set to empty star
            }
        }
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
