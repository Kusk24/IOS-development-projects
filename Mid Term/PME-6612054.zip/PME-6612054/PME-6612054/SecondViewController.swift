//
//  SecondViewController.swift
//  PME-6612054
//
//  Created by Win Yu Maung on 27/07/2024.
//

import UIKit

class SecondViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return Favourite.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = SecondTableView.dequeueReusableCell(withIdentifier: "Firstcell") as! FirstTableViewCell
        let item = Favourite[indexPath.row]
        cell.restaurant.image = UIImage(named: item.images[1])
        cell.restaurantName.text = item.name
        cell.restaurantLocation.text = item.location
        
        let isFavorite = favoriteStatus[indexPath.row] ?? false
        let heartImageName = isFavorite ? "heart.fill" : "heart"
        cell.heartButton.setImage(UIImage(systemName: heartImageName), for: .normal)
        
        cell.heartButton.tag = indexPath.row
        cell.heartButton.addTarget(self, action: #selector(heartClicked(_:)), for: .touchUpInside)
        cell.ratings.text = String(item.rating)
        
        cell.openingtime.text = item.openingTime
        cell.price.text = item.price
        let myimages: [UIImageView]

        switch item.rating {
        case ..<2:
            myimages = [cell.image1]
        case 2..<3:
            myimages = [cell.image1, cell.image2]
        case 3..<4:
            myimages = [cell.image1, cell.image2, cell.image3]
        case 4..<5:
            myimages = [cell.image1, cell.image2, cell.image3, cell.image4]
        case 5...6:
            myimages = [cell.image1, cell.image2, cell.image3, cell.image4, cell.image5]
        default:
            myimages = []
        }

        // Set star images
        let allImages = [cell.image1, cell.image2, cell.image3, cell.image4, cell.image5]
        for (index, imageView) in allImages.enumerated() {
            if index < myimages.count {
                imageView?.image = UIImage(systemName: "star.fill")
            } else {
                imageView?.image = UIImage(systemName: "star") // Assuming you want to clear or set to empty star
            }
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 250
    }

    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let Second = storyboard?.instantiateViewController(withIdentifier: "FirstDetail") as! FirstDetailViewController
        
        Second.mine = itemList[indexPath.row]
        navigationController?.pushViewController(Second, animated: true)
    }
    @IBOutlet weak var SecondTableView: UITableView!

    override func viewDidLoad() {
        super.viewDidLoad()
        SecondTableView.delegate = self
        SecondTableView.dataSource = self
        // Do any additional setup after loading the view.
        if let restaurantData = JSONParser.loadJSON(filename: "Restaurants") {
            itemList = restaurantData.items
        }
        
        let appearance = UINavigationBarAppearance()
        appearance.backgroundColor = .systemRed
        appearance.titleTextAttributes = [.foregroundColor: UIColor.white]
        
        
        navigationController?.navigationBar.scrollEdgeAppearance = appearance

    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    @objc func heartClicked(_ sender: UIButton) {
        let indexPathRow = sender.tag
        let isCurrentlyFavorite = favoriteStatus[indexPathRow] ?? false
        let newFavoriteStatus = !isCurrentlyFavorite
        
        favoriteStatus[indexPathRow] = newFavoriteStatus
        let heartImageName = newFavoriteStatus ? "heart.fill" : "heart"
        sender.setImage(UIImage(systemName: heartImageName), for: .normal)
        
        let item = Favourite[indexPathRow]
        if newFavoriteStatus {
            Favourite.append(item)
        } else {
            if let index = Favourite.firstIndex(where: { $0.name == item.name && $0.location == item.location }) {
                Favourite.remove(at: index)
            }
        }
    }

}
