//
//  Favourite.swift
//  PME-6612054
//
//  Created by Win Yu Maung on 27/07/2024.
//

import Foundation
var Favourite : [Item] = []
var favoriteStatus: [Int: Bool] = [:]
